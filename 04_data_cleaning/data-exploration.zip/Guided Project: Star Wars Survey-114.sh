## 1. How Guided Projects Work ##


