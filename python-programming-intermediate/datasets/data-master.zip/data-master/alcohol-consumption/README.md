http://fivethirtyeight.com/datalab/dear-mona-followup-where-do-people-drink-the-most-beer-wine-and-spirits/

Units: Average serving sizes per person  
Source: World Health Organisation, Global Information System on Alcohol and Health (GISAH), 2010
