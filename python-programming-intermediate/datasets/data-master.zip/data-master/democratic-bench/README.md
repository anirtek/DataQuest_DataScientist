### Democratic bench

Header | Definition
---|---------
`cand` | Candidate
`raised_exp` | Amount the candidate was expected to raise
`raised_act` | Amount the candidate actually raised
