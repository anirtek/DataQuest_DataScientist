## 2. Introduction to the data ##

import pandas as pd
reviews = pd.read_csv("fandango_scores.csv")
norm_reviews = reviews[['FILM', 'RT_user_norm', 'Metacritic_user_nom', 'IMDB_norm', 'Fandango_Ratingvalue', 'Fandango_Stars']]
#norm_reviews = reviews[]
print(norm_reviews[:1])

## 4. Creating Bars ##

import matplotlib.pyplot as plt
from numpy import arange
fig, ax = plt.subplots() # Create a single subplot and assign the returned Figure object to fig and the returned Axes object to ax
num_cols = ['RT_user_norm', 'Metacritic_user_nom', 'IMDB_norm', 'Fandango_Ratingvalue', 'Fandango_Stars']
# Generate a bar plot with:
# left set to bar_positions
# height set to bar_heights
# width set to 0.5
bar_heights = norm_reviews[num_cols].iloc[0].values
bar_positions = arange(5) + 0.75
ax.bar(bar_positions, bar_heights, 0.5)
plt.show()

## 5. Aligning Axis Ticks And Labels ##

num_cols = ['RT_user_norm', 'Metacritic_user_nom', 'IMDB_norm', 'Fandango_Ratingvalue', 'Fandango_Stars']
bar_heights = norm_reviews[num_cols].iloc[0].values
bar_positions = arange(5) + 0.75
tick_positions = range(1,6)
fig, ax = plt.subplots() #Create a single subplot and assign the returned Figure object to fig and the returned Axes object to ax.
ax.bar(bar_positions, bar_heights, 0.5)
ax.set_xticks(tick_positions) # We can use Axes.set_xticks() to change the positions of the ticks to [1, 2, 3, 4, 5]
ax.set_xticklabels(num_cols, rotation=90) # we can use Axes.set_xticklabels() to specify the tick labels and rotation parameter.

ax.set_xlabel("Rating Source")
ax.set_ylabel("Average Rating")
ax.set_title("Average User Rating For Avengers: Age of Ultron (2015)")
plt.show()

## 6. Horizontal Bar Plot ##

import matplotlib.pyplot as plt
from numpy import arange
num_cols = ['RT_user_norm', 'Metacritic_user_nom', 'IMDB_norm', 'Fandango_Ratingvalue', 'Fandango_Stars']

bar_widths = norm_reviews[num_cols].iloc[0].values
bar_positions = arange(5) + 0.75
tick_positions = range(1,6)

fig, ax = plt.subplots()
ax.barh(bar_positions, bar_widths, 0.5)
ax.set_yticks(tick_positions)
ax.set_yticklabels(num_cols)
ax.set_ylabel("Rating Source")
ax.set_xlabel("Average Rating")
ax.set_title("Average User Rating For Avengers: Age of Ultron (2015)")
plt.show()

## 7. Scatter plot ##

import matplotlib.pyplot as plt
# from numpy import arange
fig, ax = plt.subplots()
ax.scatter(reviews['Fandango_Ratingvalue'], reviews['RT_user_norm'])
ax.set_xlabel('Fandango')
ax.set_ylabel('Rotten Tomatoes')
plt.show()

## 8. Switching axes ##

fig = plt.figure(figsize=(5,10))
ax1 = fig.add_subplot(2,1,1)
ax2 = fig.add_subplot(2,1,2)
ax1.scatter(reviews['Fandango_Ratingvalue'], reviews['RT_user_norm'])
ax1.set_xlabel('Fandango')
ax1.set_ylabel('Rotten Tomatoes')
ax2.scatter(reviews['RT_user_norm'], reviews['Fandango_Ratingvalue'])
ax2.set_xlabel('Rotten Tomatoes')
ax2.set_ylabel('Fandango')
plt.show()

## 9. Benchmarking correlation ##

import matplotlib.pyplot as plt

fig = plt.figure(figsize=(5,10))
ax1 = fig.add_subplot(3,1,1)
ax2 = fig.add_subplot(3,1,2)
ax3 = fig.add_subplot(3,1,3)

ax1.scatter(reviews['Fandango_Ratingvalue'], reviews['RT_user_norm'])
ax1.set_xlabel('Fandango')
ax1.set_ylabel('Rotten Tomatoes')
ax1.set_xlim(0, 5)
ax1.set_ylim(0, 5)

ax2.scatter(reviews['Fandango_Ratingvalue'], reviews['Metacritic_user_nom'])
ax2.set_xlabel('Fandango')
ax2.set_ylabel('Metacritic')
ax2.set_xlim(0, 5)
ax2.set_ylim(0, 5)

ax3.scatter(reviews['Fandango_Ratingvalue'], reviews['IMDB_norm'])
ax2.set_xlabel('Fandango')
ax2.set_ylabel('IMDB')
ax1.set_xlim(0, 5)
ax1.set_ylim(0, 5)

plt.show()